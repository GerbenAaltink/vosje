typedef struct Function {
    char * name;
    

} Function;
)